import '@maket/css/style.css'
import React from 'react'
import ReactDOM from 'react-dom'
import App from '@components/App.jsx'

const wrap = document.querySelector('#wrap')

ReactDOM.render(<App />, wrap)

