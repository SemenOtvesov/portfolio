export class Page {
    constructor(params){
        this.params = params
    }

    getRoot(){}

    afterRender(){}

    destroy(){}
}