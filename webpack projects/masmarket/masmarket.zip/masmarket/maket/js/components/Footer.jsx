import React from "react";

export default ()=>{
    return(
        <footer className="footer"></footer>
    )
}