export type TgetUrlParams = {
    el: HTMLElement, 
    pathWebp: string, 
    pathPng: string,
    previewIterator: number
}